<?php

// Written in PHP 5
// Version 1.01, 22 June 2006

//require_once("class_io_file.php");
require_once("class_log_file_v200.php");


//----------------------------------------------------------------------

class program_generic
{

public $program_name;
public $program_version;
public $program_date;

public $arguments;
public $eol;

public $current_directory;
public $input_file_handle;
public $output_file_handle;
public $configuration_file_handle;
public $log_file_handle;

//----------------------------------------------------------------------

public function program_generic($name, $version, $date)
{
	$this->program_generic_name    = $name;
	$this->program_generic_version = $version;
	$this->program_generic_date    = $date;

	$this->eol = self::set_eol_character_sequence();

}

//----------------------------------------------------------------------

public function set_arguments($arguments)
{
	// There should be at least one arguments (the main php file)
	if(count($arguments) < 1)
	{
		if($this->log_file_handle != NULL)
			$this->log_file_handle->log_messages(FALSE, TAG_ERROR, "Not enough arguments sent to the program.");
		return(FALSE);
	}

	$this->arguments = $arguments;

	//print_r($this->arguments);
	
	return(TRUE);
}

//----------------------------------------------------------------------

public function create_log_file($fullname, $sdtio_handle = NULL)
{
	// Create and set the object for the log file
	// Expect full name of log file as parameter 1
	// Expect standard IO object as parameter 2
	// Return TRUE if everything is OK, FALSE otherwise

	// Notice one cannot check here if the path is correct as maybe the log file does not exist yet

	if($sdtio_handle == NULL)
		return(FALSE);

	$this->log_file_handle = new log_file();

	if($this->log_file_handle == NULL)
	{
		$sdtio_handle->log("Cannot create log file object", "Fatal Error");
		return(FALSE);
	}

	if(!$this->log_file_handle->set_file($fullname))
	{
		$sdtio_handle->log(sprintf("Cannot create log file '%s'", $fullname), "Fatal Error");
		return(FALSE);
	}
	return(TRUE);

} // function create_log_file

//----------------------------------------------------------------------

private function set_eol_character_sequence()
{
	// Determine new line character sequence upon operating system detected
	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
		return "\r\n";
	else	return "\n";

} // function get_eol_character_sequence()

//----------------------------------------------------------------------

public function get_eol()
{
	return $this->eol;
}

//----------------------------------------------------------------------

public function get_environement_variable($variable)
{
	return($_ENV[sprintf("%s", $variable)]);
}

//----------------------------------------------------------------------

public function create_configuration_file($fullpath, $sdtio_handle = NULL)
{
	if($sdtio_handle == NULL)
		return(FALSE);

	if (!realpath($fullpath))
	{
		$sdtio_handle->log(sprintf("Invalid configuration file '%s'.", $fullpath), "Fatal Error");
		return(FALSE);
	}

	$configuration = simplexml_load_file($fullpath);

	if(!$configuration)
	{
		$sdtio_handle->log("Error reading file '%s' (Check if the XML is well formed)", "Fatal Error");
		return(FALSE);
	}

	$this->configuration_file_handle = $configuration;
	
	return(TRUE);

}

//----------------------------------------------------------------------

public function set_input_file($basename)
{
	$filename = sprintf("%s/%s", $this->current_directory, $basename);

	if($this->input_file_handle == NULL)
		return (FALSE);

	$this->input_file_handle->set_filename($filename);

	if(!$this->input_file_handle->filename_exists())
		return(FALSE);

	return(TRUE);

}

//----------------------------------------------------------------------

public function create_output_file($name, $basename_only_given = TRUE)
{
	$filename = "";

	if($basename_only_given)
		$filename = sprintf("%s/%s", $this->current_directory, $name);
	else
		$filename = $name;

	$this->output_file_handle = new io_file();

	if($this->output_file_handle == NULL)
	{
		if($this->log_file_handle != NULL)
			$this->log_file_handle->log_messages(FALSE, TAG_ERROR, sprintf("Could not create object for output file '%s'.", $filename));
		return(FALSE);
	}

	$this->output_file_handle->set_filename($filename);

	return(TRUE);

}

//----------------------------------------------------------------------

public function log_start()
{
	$this->log_file_handle->log_separator();

	$this->log_file_handle->log_messages(TRUE, TAG_EXECUTION, sprintf("Start program (name='%s', version='%s', date='%s')",
					     $this->program_generic_name, $this->program_generic_version, $this->program_generic_date));

} // function log_start

//----------------------------------------------------------------------

public function log_end($exit_code)
{
	$message = sprintf("End program (name='%s', version='%s', date='%s'), exit code is '%s')", $this->program_generic_name, $this->program_generic_version, $this->program_generic_date, $exit_code);

	$this->log_file_handle->log_messages(TRUE, TAG_EXECUTION, $message);

	$this->log_file_handle->log_separator();

} // function log_end

//----------------------------------------------------------------------

} // class program


//----------------------------------------------------------------------




?>