<?php

// Written in PHP version 5
// Version 0.3, June 2005

//----------------------------------------------------------------------

class log_stdio
{

// Methods

//-----------------------

private function get_timestamp()
{
	return date("D M d Y G:i:s");
	
} // public function get_timestamp()

//-----------------------

public function log_stdio()
{
	$this->eol = get_eol_character_sequence();
}

//-----------------------

public function log($message = "", $type = "")
{
	if(($message == "") and ($type == ""))
		$date = "";
	else
		$date = sprintf("<d>%s</d>", $this->get_timestamp());

	if($message != "")
		$message = sprintf("<m>%s</m>", $message);

	if($type != "")
		$type = sprintf("<t>%s</t>", $type);

	printf("%s %s %s %s", $message, $type, $date, PHP_EOL);

} // log()

//-----------------------

} // class log_stdio

?>