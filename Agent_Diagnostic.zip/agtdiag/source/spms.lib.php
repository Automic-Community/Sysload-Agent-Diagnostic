<?php

//This line hide errors 
ini_set( "display_errors", 0);
	// Definition of constant variables for improving code legibility
	
	// Columns returned by the Management Server query "agtlist"
	define("AGTLIST_COL_TYPE", 1);
	define("AGTLIST_COL_NAME", 2);
	define("AGTLIST_COL_INST", 3);
	define("AGTLIST_COL_IP",   6);
	define("AGTLIST_COL_PORT", 7);

// ----------------------------------------------------------------------------

function spms_encode_agent_id(&$agent_id, $agent_type_id, $agent_name, $agent_instance_name = "")
{
	// An agent ID is of the form '<agent type ID>;<agent name>;<agent instance name>'

	$agent_id = sprintf("%s;%s;%", $agent_type_id, $agent_name, $agent_instance_name);
}

// ----------------------------------------------------------------------------

function spms_decode_agent_id($agent_id, &$agent_type_id, &$agent_name, &$agent_instance_name)
{
	// An agent ID is of the form '<agent type ID>;<agent name>;<agent instance name>'

	$agent_id_table = explode(";", $agent_id);
	list($agent_type_id, $agent_name, $agent_instance_name) = $agent_id_table;

	//$message = sprintf("agent id given '%s', agent type id '%s', agent_name '%s', agent instance name '%s'", $agent_id, $agent_type_id, $agent_name, $agent_instance_name);
	//$this->log_handle->printlog(TAG_DEBUG, $message);

}

// ----------------------------------------------------------------------------

function spms_query($query)
{
	$result = FALSE;

	// printf($message);
	$query = sprintf("%s&cnx=2&snd=5",$query);
	// Send the query (open it as if it was a file)
	$handle = fopen($query, "r");
	
	// In some cases when the "fopen" does not work, the code does not go any further and the error is not managed below
	
	// Error check
	if($handle === FALSE)
	{
		$message = "ERROR - Could not send query '%s' to management server or query returned in error\r\n";
		printf($message, $query);
		return(FALSE);
	}

	// 'trim' is used to get rid of the chr(13) at the end of the line returned
	while($line = trim(fgets($handle))) 
	{
		$result[] = $line;
	}
	
	return($result);

}

// ----------------------------------------------------------------------------

function spms_get_all_managed_objects($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password)
{
	$managed_objects = NULL;
	
	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtlist&username=%s&password=%s&outputformat=csv", $ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
		return(NULL);

	foreach($lines as $line)
	{
		$columns = explode(";", $line);
		
		#	type	name	instance	alias	desc	address	port	histactivityhost	histactivityport	histactivitypath	histeventhost	histeventport	histeventpath	eventmodelhost	eventmodelport	eventmodelpath	inipath	entityinipath	scriptfilepath	logfilepath	authfilepath	os

		// Associate variables to fields
		$managed_object["agent_name"] = $columns[AGTLIST_COL_NAME];
		$managed_object["agent_type"] = $columns[AGTLIST_COL_TYPE];
		$managed_object["agent_instance_name"] = $columns[AGTLIST_COL_INST];
		
		$managed_objects[] = $managed_object;
	}
	
	return $managed_objects;
	

}

// ----------------------------------------------------------------------------

function spms_get_managed_object_history_metrics($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name)
{

	$metrics = NULL;
	
	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=getagthstmetrics&username=%s&password=%s&agent=%s;%s;%s&showheader=0&outputformat=csv", $ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name);

	$lines = spms_query($query);

	//print_r($lines);
	
	if($lines == NULL)
		return(NULL);

	foreach($lines as $line)
	{
		# type	name	instance	metric name	metric instance	unit	label	sysload code	full sysload code	status	message


		$row = explode(";", $line);

		list($agent_type_id, $agent_name, $agent_instance_name, $metric_name, $metric_instance_name, $metric_unit, $metric_label, $metric_code_short, $metric_code_full, $status, $message) = $row;

		$metric = NULL;

		$metric["metric_name"] = $metric_name;
		$metric["metric_instance_name"] = $metric_instance_name;
		$metric["metric_unit"] = $metric_unit;
		$metric["metric_label"] = $metric_label;
		$metric["metric_code_short"] = $metric_code_short;
		$metric["metric_code_full"] = $metric_code_full;
		$metric["status"] = $status;
		$metric["message"] = $message;

		$metrics[] = $metric;
	}

	return($metrics);

} // function spms_get_agent_history_metrics

// ----------------------------------------------------------------------------

function spms_managed_object_history_data($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name, $metric, $metric_instance_name, $date)
{

	$values = NULL;
	
	$unit = "HOUR";

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=getagthstdata&username=%s&password=%s&agent=%s;%s;%s&metric=%s&instance=%s&date=%s&enddate=%s&unit=%s&showheader=0&outputformat=csv", $ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name, $metric, $metric_instance_name, $date, "2011-06-22", "HOUR");

	$lines = spms_query($query);
	
	//print_r($lines);
	//return;
	
	// Return immediately if error in the query
	if($lines == FALSE)
		return(NULL);

	foreach($lines as $line)
	{
		# type	name	instance	datetime	value	%info	average	%infoavg	status	message
		
		$row = explode(";", $line);

		list($agent_type_id, $agent_name, $agent_instance_name, $datetime, $value, $percent_info, $average, $percent_info_average, $status, $message) = $row;
		
		$value_row = NULL;
		
		$value_row["datetime"] = $datetime;
		$value_row["value"] = $value;
		
		$values[] = $value_row;
	}

	return($values);
	
}

//----------------------------------------------------------------------

function spms_get_groups($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password)
{
	// Unload group definition from management server

	$groups = NULL;
	
	// http://frlpmsys01:9900/services/sldmgts/sldapi/api_execute?method=agtgrouplist&username=admin&password=sysload&outputformat=html
	
	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtgrouplist&username=%s&password=%s&showagents=1&outputformat=csv", $ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password);

	$lines = spms_query($query);

	if($lines == FALSE)
		return(FALSE);

		
	//zone	zone_sde		0.00	0.00	0.00	0.00	1
	//category	dummy		0.00	0.00	0.00	0.00	1
	//category	Support		0.00	0.00	0.00	0.00	3	
	
	//print_r($lines);

	// Is the table already sorted by management server?
	
	foreach($lines as $line)
	{
		// Agents are surrounded by double quotes 
		$field_table = explode("\"", $line);

		list($group_section, $agent_section, $dummy_section) = $field_table;

		//$message = sprintf("group section '%s'", $group_section);
		//$this->log_handle->printlog(TAG_INFO, $message);


		//echo($row);

		$group = NULL;

		// Is the column agents there event if showagents = 0?
	
		$group_section_table = explode(";", $group_section);

		// Separate table columns
		list($group_index, $group_class_name, $group_name, $group_description, $group_proc_capacity, $group_mem_capacity, $group_disk_capacity, $group_net_capacity, $no_agents) = $group_section_table;
		
		$group['class_name'] = $group_class_name;
		$group['group_name'] = $group_name;

		//$message = sprintf("Found group '%s' in class '%s'", $group_name, $group_class_name);
		//printf($message);
		//return(TRUE);
		
		
		//$message = sprintf("agent section '%s'", $agent_section);
		//$this->log_handle->printlog(TAG_DEBUG, $message);

		
		//27;category;boree;;0.00;0.00;0.00;0.00;1;"NT;boree;";
		
		// THE CASE BELOW SHOULD BE HANDLED BETTER
		//28;category;Prototype HMC;;0.00;0.00;0.00;0.00;0;;
		
		$managed_objects = NULL;

		if ($no_agents != "0")
		{
			$tmp_agent_table = explode(",", $agent_section);

			foreach($tmp_agent_table as $agent_id)
			{

				//$message = sprintf("agent '%s'", $agent_id);
				//$this->log_handle->printlog(TAG_DEBUG, $message);

				$managed_object = NULL;

				spms_decode_agent_id($agent_id, $agent_type_id, $agent_name, $agent_instance_name);

				$managed_object['agent_type_id'] = $agent_type_id;
				$managed_object['agent_name'] = $agent_name;
				$managed_object['agent_instance_name'] = $agent_instance_name;

				//$message = sprintf("Found agent, type '%s', agent name '%s', agent instance name '%s'", $agent_type_id, $agent_name, $agent_instance_name);
				//$this->log_handle->printlog(TAG_DEBUG, $message);

				$managed_objects[] = $managed_object;

			} // foreach
		}
		
		$group['managed_objects'] = $managed_objects;


		$groups[] = $group;

	} // foreach

	return($groups);
}

//----------------------------------------------------------------------

function spms_get_managed_object_group_members($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $group_class_name, $group_name)
{

	$groups = spms_get_groups($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password);
	
	if($groups == FALSE)
	{
		return(FALSE);
	}
	
	//print_r($groups);
	
	// Check if the array is empty (no group)
	if($groups == NULL)
	{
		return(FALSE);
	}

	foreach($groups as $group)
	{
		if ( ($group['class_name'] == $group_class_name) && ($group['group_name'] == $group_name) )
		{
			// The group has been found, return its members (may be NULL)
			return($group['managed_objects']);
		}
	}
	
	// The group has not been found, return FALSE
	return(FALSE);
	
} // 

//----------------------------------------------------------------------

function spms_add_managed_object($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $hist_activity_host, $hist_activity_path)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtadd&type=%s&name=%s&username=%s&password=%s&outputformat=csv&showheader=1&address=vmstm2k872&histactivityhost=%s&histactivityport=9502&histactivitypath=%s", $ms_host_id, $ms_port_no, $ms_service_name, $agent_type, $agent_name, $user_name, $user_password,$hist_activity_host, $hist_activity_path);
	
	//printf("%s%s", $query, PHP_EOL);

	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return(TRUE);

}

//----------------------------------------------------------------------

function spms_get_data_bulk($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password,$agents,$metric_code, $date )
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=getagthstdatabulk&username=%s&password=%s&agents=%s&unit=day&metric=%s&instance=&date=%s&enddate=%s 23:55&showheader=1&outputformat=csv", $ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password,$agents,$metric_code, $date, $date);
	
	//printf("%s%s", $query, PHP_EOL);

	$lines = spms_query($query);
	if($lines == NULL || $lines == FALSE)
	{
		return(FALSE);
	}
	
	return($lines);

}
//----------------------------------------------------------------------

function spms_auto_uptdate_managed_object($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtautoupdate&type=%s&name=%s&username=%s&password=%s&outputformat=csv&showheader=1", $ms_host_id, $ms_port_no, $ms_service_name, $agent_type, $agent_name, $user_name, $user_password);
	
	printf("%s%s", $query, PHP_EOL);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return(TRUE);

}

//----------------------------------------------------------------------

function spms_activate_managed_object_for_spportal($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtusedinsysloadportalset&value=1&type=%s&name=%s&username=%s&password=%s&outputformat=csv&showheader=1", $ms_host_id, $ms_port_no, $ms_service_name, $agent_type, $agent_name, $user_name, $user_password);
	
	//printf("%s%s", $query, PHP_EOL);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return(TRUE);

}

//----------------------------------------------------------------------

function spms_remove_managed_object($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtremove&username=%s&password=%s&type=%s&name=%s&instance=%s",$ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name);

		//printf("%s%s", $query, PHP_EOL);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return(TRUE);
}

//----------------------------------------------------------------------

function spms_ping_managed_object($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtping&username=%s&password=%s&type=%s&name=%s&instance=%s",$ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent_type, $agent_name, $agent_instance_name);

		//printf("%s%s", $query, PHP_EOL);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return($lines);
}

//----------------------------------------------------------------------

function spms_deactivate_managed_object_for_spportal($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $agent)
{

	$query = sprintf("http://%s:%s/services/%s/sldapi/api_execute?method=agtusedinsysloadportalsetall&value=0&agents=%s&username=%s&password=%s&outputformat=csv&showheader=0", $ms_host_id, $ms_port_no, $ms_service_name,$agent, $user_name, $user_password);
	
	//printf("%s%s", $query, PHP_EOL);
	
	$lines = spms_query($query);
	
	if($lines == NULL)
	{
		return(FALSE);
	}
	
	return($lines);

}
?>
