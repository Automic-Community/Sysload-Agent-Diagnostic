<?php
set_time_limit(0);
// Written in PHP 5
// Version 1.00 25 Nov 2011

include_once 'class_program_generic_v201.php';
require_once 'common.php';
require_once 'spms.lib.php';

//----------------------------------------------------------------------

class program extends program_generic
{

// Private variables
private $trace_debug;

//----------------------------------------------------------------------

public function program($name, $version, $date)
{
	$this->trace_debug = FALSE;
	self::program_generic($name, $version, $date);

} // function program_sldpem

//----------------------------------------------------------------------

public function set_traces()
{
	// Exit in case there is an internal problem with the configuration file
	if($this->configuration_file_handle ==  NULL)
		return(FALSE);

	// Set traces according to the configuration file
	if($this->configuration_file_handle->trace->debug == "1")
		$this->trace_debug = TRUE;

} // function set_traces()

//----------------------------------------------------------------------

public function validate_arguments()
{
	
	return(TRUE);
	
} // function validate_arguments


//----------------------------------------------------------------------

public function execute()
{

	// Start the actual execution of the program
	
	//
	// Variables that need to be customized
	//
	$deactivate_spp_flag = 1;
	// Management Server host ID (IP address, does not always work with hostname)
	$ms_host_id = "vmstm2k870";

	// Port number used by the Communication Server acting as a broker for Management Server (typically "9900")
	$ms_port_no = "9900";

	// Management Server service ID for Communication Server (typically "sldmgts")
	$ms_service_name = "sldmgts";

	// User credentials for connecting to Management Server
	$user_name = "admin";
	$user_password = "sysload";

	// Input file for metric IDs to check
	$metric_file_path = "E:\\devphp\\agtdiag\\metric_file.csv";
	
	//% of presence value, under this limit, the agent will be log
	$threshold_no_data = 50;
	
	//$group_name = "Product Management";
	$group_name = "A2";
	
	// Directory to contain reports
	$directory_folder = "E:\\devphp\\agtdiag\\reports";
	
	//
	// End of variables that need to be customized
	//

	// Lire le groupe de Managed Object pass� en entr�e
	// Peut �tre d�fini par variable pour commencer

	// Lire le fichier de m�triques � v�rifier sur chaque type de Managed Object
	
	//Declaration of array 
	
	//this one will contains Managed Objects with missing value
	$missing_managed_object_metrics;
	
	//this one will contains the result for deactivatiing SP Portal ( if you wanted it )
	$resultflag;
	
	//this one will contains Managed Objects which did not respond
	$error_managed_objects;
	
	
	// Query the metric file
	$metric_file_handle = fopen($metric_file_path, "r");
	
	if($metric_file_handle == FALSE)
	{
		$message = sprintf("Could not open metric file '%s'", $metric_file_path);
		$this->log_file_handle->log_messages(FALSE, TAG_ERROR_FATAL, $message);
		return(FALSE);
	}
	
	$message = sprintf("Successfully opened metric file '%s'", $metric_file_path);
	$this->log_file_handle->log_messages(FALSE, TAG_INFO, $message);

	
	// Constituer la liste des Managed Objects membres du Groupe de Managed Object
	// Placer dans un tableau
	$groups = spms_get_groups($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password);
	if ($groups == NULL) {
		$message = sprintf("Could not get groups");
		$this->log_file_handle->log_messages(FALSE, TAG_ERROR_FATAL, $message);
		return(FALSE);
	}
	// Lire le fichier de m�triques � v�rifier
	foreach  ($groups as $group) {
		if (strcmp($group['group_name'],$group_name) == 0 ) {
			$mygroups[] = $group;
		}
	}

	$line = fgets($metric_file_handle);
	$line = fgets($metric_file_handle);
	$my_code_agent="";
	while ($line != False ) {
		
		list($code_agent,$domain_en,$range_en,$unit_en,$metric_long_en,$domain_fr,$range_fr,$unit_fr,$metric_long_fr,$code_short,$code_long,$code_metametric,$description,$source_information,$comments_public,$comments_confidential) = explode(";",$line);
		$code_long = trim($code_long);
		//Test if this code_agent was process 
		if (strcmp($my_code_agent,$code_agent) !=0 ) 
		{
			$my_code_agent = $code_agent;
			$myagents="";
			foreach ($mygroups as $group ) 
			{
				foreach($group['managed_objects'] as $managed_object ) 
				{
					
					//Test if this agent is this type
					if ( strcasecmp($managed_object['agent_type_id'],$my_code_agent) == 0) 
					{
					//ping the managed object 
						$ping =  spms_ping_managed_object($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password,$managed_object['agent_type_id'],$managed_object['agent_name'], $managed_object['agent_instance_name'] );
						list($status_code,$status,$ver,$mess) = explode(";",$ping[0]);
						
						//Test if the managed object respond
						if  ((strcmp($status,"1")) == 0) 
						{
						
							if ( strcmp($myagents, "" )== 0) 
							{
								$myagents .=  $managed_object['agent_type_id'] . ";" . $managed_object['agent_name'] . ";" . $managed_object['agent_instance_name']; 
							} else 
							{
								$myagents .=  "," . $managed_object['agent_type_id'] . ";" . $managed_object['agent_name'] . ";" . $managed_object['agent_instance_name']; 
							}
							
						} 
						else //If it didn't  respond
						{				
							$error_managed_objects[] = $managed_object;
							if ($deactivate_spp_flag == 1 ) 
							{
								if ( strcmp($mydownagents, "" )== 0) 
								{
									$mydownagents .=  $managed_object['agent_type_id'] . ";" . $managed_object['agent_name'] . ";" . $managed_object['agent_instance_name']; 
								} 
								else 
								{
									$mydownagents .=  "," . $managed_object['agent_type_id'] . ";" . $managed_object['agent_name'] . ";" . $managed_object['agent_instance_name']; 
								}
							}
						}
					}
				}
			}
		}
		
		if ( $deactivate_spp_flag ==1 ) 
		{
			//send request for deactivating SP Portal flag
			$resultflag = spms_deactivate_managed_object_for_spportal($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password, $mydownagents);
			//array_shift($resultflag);
		}
		
		//Format the date
		$date = date("Y-m-d",strtotime("-1 day"));
		
		//Request the agents
		if (!(strcmp($myagents,"")==0))
		{
			
			$result = spms_get_data_bulk($ms_host_id, $ms_port_no, $ms_service_name, $user_name, $user_password,$myagents,$code_long, $date );
			
		
			if ($result == FALSE ) 
			{
				$message = sprintf("Could not request '%s' for '%s'", $code_long, $myagents);
				$this->log_file_handle->log_messages(FALSE, TAG_ERROR_FATAL, $message);
				break;
			}
		}else {
		//else reset the result
		$result = 0;
		}
		$limite = count($result);
		for ($i = 1; $i < $limite; $i++ ) 
		{
			//Browse results
			list($type,$name,$instance,$datetime,$value,$info,$average,$infoavg,$status,$message) = explode(";", $result[$i]); 
			
			//Test the presence of value, if it's under the threshold it'll be log
			if ($infoavg < $threshold_no_data) 
			{
				$missing_managed_object_metrics[] = array( "name"=>$name, "type"=>$type, "domain_en"=>$domain_en, "metric_long_en"=>$metric_long_en, "code_long"=>$code_long, "code_short"=>$code_short);
			}		
		}
		//Read the next line of .csv file
		$line = fgets($metric_file_handle);
	}
	
	//if (!mkdir("E:/devphp/agtdiag/report"))
	//{
	//	$message = sprintf("Could not create report directory");
	//	$this->log_file_handle->log_messages(FALSE, TAG_ERROR_FATAL, $message);
	//	return(FALSE);
	//}
	
	$reportdate = date("Ymd");
	$myfile = sprintf("%s\\report-%s-%s.txt", $directory_folder, $reportdate, $group_name);
	$mylog = fopen($myfile,a);
	
	// 25/11/2011, SDE. We should check if the file could be opened and manage potential errors
	
	//Loop for printing Managed Object which could not be contacted
	if (  !($error_managed_objects == NULL) )
	{
		$head = sprintf("Those Managed Object did not respond: %s",PHP_EOL);
		fputs($mylog,$head);
		array_multisort($error_managed_objects, SORT_STRING);
		foreach ($error_managed_objects as $emo ) 
		{					
			//$emo = sprintf("%s",$emo);
			
			if ( strcmp($emo['agent_instance_name'],"") == 0 ) 
			{
				$currentline = sprintf("%s",$emo['agent_name']);
			} 
			else 
			{
				$currentline = sprintf("%s.%s", $emo['agent_instance_name'],  $emo['agent_name']);
			}
			$currentline = sprintf("Managed Object '%s' ('%s') could not be contacted%s", $currentline, $emo['agent_type_id'], PHP_EOL);
			fputs($mylog,$currentline);
			}
	}
	
	fputs($mylog,PHP_EOL);
	
	//Loop for printing Managed Object which are deactivated in SP Portal
	if ( $deactivate_spp_flag == 1)
	{
		$head = sprintf("Those Managed Object have been deactivated or not: %s",PHP_EOL);
		fputs($mylog,$head);
		foreach ( $resultflag as $rf )
		{
			list($rf_number,$rf_type,$rf_name,$rf_instance,$rf_status,$rf_message) = explode(";",$rf);
		
			if ( strcmp($rf_instance,"") == 0 ) 
			{
				$currentline = sprintf("%s",$rf_name);
			} 
			else 
			{
				$currentline = sprintf("%s.%s", $rf_instance,  $rf_name);
			}
			if($rf_status == 1 ) 
			{
				$statusline = "has been";
			} else 
			{
				$statusline = "has not been";
			}
			$rf_line = sprintf("Managed Object %s %s deactivated in SP Portal %s",$currentline,$statusline, PHP_EOL);
			fputs($mylog,$rf_line);		
		}
	}
	
	fputs($mylog,PHP_EOL);
	
	//Loop for printing Managed Object with missing values
	if (  !($missing_managed_object_metrics == NULL) )
	{
		$head = sprintf("Missing metric values on Managed Objects:%s", PHP_EOL);
		fputs($mylog,$head);
		array_multisort($missing_managed_object_metrics, SORT_STRING);
		foreach ( $missing_managed_object_metrics as $mmom )
		{
			//list($type,$name,$instance,$datetime,$value,$info,$average,$infoavg,$status,$message) = explode(";", $mmom);
			$mmom = sprintf("Managed Object '%s' ('%s') is missing metric '%s' > '%s' ('%s', '%s') %s", $mmom["name"], $mmom["type"], $mmom["domain_en"], $mmom["metric_long_en"], $mmom["code_long"], $mmom["code_short"],PHP_EOL);
			//$mmom = sprintf("%s %s",$mmom, PHP_EOL);
			fputs($mylog,$mmom);		
		}
	}

	return(TRUE);

} // function execute


//----------------------------------------------------------------------

	
} // class program


//----------------------------------------------------------------------



?>
