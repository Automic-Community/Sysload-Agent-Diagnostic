<?php

// Constants

define("EXIT_CODE_NORMAL", "Normal end");
define("EXIT_CODE_ABNORMAL", "Abnormal end");

//----------------------------------------------------------------------

function get_eol_character_sequence()//autant utiliser PHP_EOL
{
	// Determine new line character sequence upon operating system detected

	if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN')
		return "\r\n";
	else
		return "\n";

} // function get_eol_character_sequence()

//----------------------------------------------------------------------

function dbg($string)
{
	printf("%s%s", $string, PHP_EOL);

} // function dbg

//----------------------------------------------------------------------

?>