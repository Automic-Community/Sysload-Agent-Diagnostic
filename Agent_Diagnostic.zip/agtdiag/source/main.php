<?php

// Writen in PHP version 5
// See constants for version

//----------------------------------------------------------------------

// Constants

define("PGM_NAME", "agtdiag");
define("PGM_VERSION", "1.00");
define("PGM_DATE", "08 nov 2011");

//----------------------------------------------------------------------

require_once("common.php");
require_once("class_program.php");
require_once("class_log_stdio.php");

//----------------------------------------------------------------------

function get_home_directory()
{
	// Construct the home directory from the full path of this script "main.php"
	
	$script_directory = dirname($_SERVER['SCRIPT_NAME']);
	return realpath($script_directory . "/..");

} // get_home_directory

//----------------------------------------------------------------------

function exit_main($exit_code, $sdtio_handle = NULL)
{

	if($exit_code == EXIT_CODE_NORMAL)
		$return_code = 1;
	else
		$return_code = 0;
	
	if($sdtio_handle != NULL)
	{
		$sdtio_handle->log("", "");
		$sdtio_handle->log($exit_code, "Execution");
	}

	exit($return_code);

} // exit_main

//----------------------------------------------------------------------

// Set an object for the program
// Object of specific type for this program, based on a generic class of type program_generic

$stdio_handle = new log_stdio();

$stdio_handle->log("Start program", "Execution");

$program_handle = new program(PGM_NAME, PGM_VERSION, PGM_DATE);

// Set configuration file

$home_directory = get_home_directory();


if(!$home_directory)
{
	$stdio_handle->log("Could not detect home directory", "Fatal error");
	exit_main(EXIT_CODE_ABNORMAL, $stdio_handle);
}

// Full path of the configuration file
$configuration_file_fullname = $home_directory . "/" . PGM_NAME . ".xml";

// Full path of the log file
$log_file_fullname = $home_directory . "/" . PGM_NAME . ".log";

// Create configuration file object

if(!$program_handle->create_configuration_file($configuration_file_fullname, $stdio_handle))
	exit_main(EXIT_CODE_ABNORMAL, $stdio_handle);

// Set the verbose level of the log file according to the configuration file

$program_handle->set_traces();

// Create log file object

if(!$program_handle->create_log_file($log_file_fullname, $stdio_handle))
	exit_main(EXIT_CODE_ABNORMAL, $stdio_handle);

// Write the start of exectuion in the log file

$program_handle->log_start();


// Set arguments, those given by php.exe
//print_r($_SERVER['argv']);

if(!$program_handle->set_arguments($_SERVER['argv']))
	exit_main(EXIT_CODE_ABNORMAL, $stdio_handle);

// Check arguements

if(!$program_handle->validate_arguments())
	exit_main(EXIT_CODE_ABNORMAL, $stdio_handle);

// Set the exit code to normal as default
$exit_code=EXIT_CODE_NORMAL;

// Enter the main part of the program

if(!$program_handle->execute())
	$exit_code=EXIT_CODE_ABNORMAL;

$program_handle->log_end($exit_code);

exit_main($exit_code, $stdio_handle);

?>