<?php

require_once("common.php");

// Written in PHP version 5
// Version 1.02w1, July 2007

//----------------------------------------------------------------------

define("TAG_EXECUTION", "execution");
define("TAG_ERROR_FATAL", "fatal_error"); // 25/7/2007 end tag badly managed if no _
define("TAG_ERROR", "error");
define("TAG_WARNING", "warning");
define("TAG_INFO", "info");
define("TAG_TRACE_DEBUG", "trace level=\"debug\"");

class log_file
{

// Handler for a log file

private $file_name_full;	// The full name of the log file
private $file_handle;		// File handler of the log
private $eol;				// End of line character sequence

//-----------------------

private function get_timestamp()
{
	return date("D M d Y G:i:s");
	
} // public function get_timestamp()

//-----------------------

function log_file()
{
	$this->eol = get_eol_character_sequence();
}

//-----------------------

function set_file($file_name_full)
{
	$this->file_name_full = $file_name_full;

	if(!self::open_file())
	{
		//debug("Cannot set log file ('$file_name_full')");
		return(FALSE);
	}

	return(TRUE);
}

//-----------------------

function open_file()
{
	// Opens the file for adding data at the end of it
	// Creates the file if does not exist
	// Returns FALSE if there is a problem, TRUE if OK

	// Open file
	if (!($this->file_handle = fopen($this->file_name_full, "a")))
		return(FALSE);

	return(TRUE);

} // public function open_file($file_name_full)

//-----------------------

function close_file()
{
	fclose($this->file_handle);

} // public function close_file()

//-----------------------

function log_separator()
{
	$chain = "";
	for($i = 0 ; $i < 71 ; $i++)
		$chain = $chain . "-";

	if(!self::open_file())
		return(FALSE);

	fprintf($this->file_handle, sprintf("<!-- %s -->", $chain) . $this->eol);

	self::close_file();

	return(TRUE);
}

//-----------------------

function log_messages()
{
	// Add some messages to the log in an XML node

	// Input parameters expected:
	//
	// 0: TRUE or FALSE, indicate whether the timestamp should be displayed. 
	// 1: XML tag 'erreur, warning, debug'
	// 2: Message
	// 3: Message...
	//
	// Or
	//
	// 2: Array of messages

	$with_date = func_get_arg(0);
	$tag = func_get_arg(1);

	// Create a table containing the messages

	$third_argument = func_get_arg(2);

	if(is_string($third_argument))
	{
		// Argument 3 is a string, consider the rest of the argments also as strings and put all in a table

		for($argument_index = 2; $argument_index < func_num_args(); $argument_index++)
		{
			$argument = func_get_arg($argument_index);
			if(is_string($argument))
				$messages[] = $argument;
		}
	}
	else
	{
		// Argument 3 is a table

		$messages = $third_argument;
	}

	$space_pos = strpos($tag, " ");
	if ($space_pos == NULL)
		$tag_end = $tag;
	else
		$tag_end = substr($tag, 0, $space_pos);

	if(!self::open_file())
		return(FALSE);

// Beginning of modif 1/08/2007

	$string = "";
	$tag_open = sprintf("<%s>", $tag);
    $date = "";
	$string_of_messages = "";
	$tag_close = sprintf(" </%s>", $tag);

	if ($with_date)
		$date = sprintf(" <d> %s </d>", self::get_timestamp());

	foreach($messages as $index=>$message)
		$string_of_messages .= sprintf(" <m> %s </m>", $message);
		

	// Construction of the line to print
	$string = sprintf("%s%s%s%s%s", $tag_open, $date, $string_of_messages, $tag_close, PHP_EOL);

	//dbg($string);

	// Print line to file
	// Character '%' has to be managed when printing to file (not when printing to standard output)
	fprintf($this->file_handle, str_replace("%", "%%", $string));

// End of modif 1/08/2007

	self::close_file();

	return(TRUE);

} // public function log_messages

//-----------------------
//-----------------------

} // class log_file


?>